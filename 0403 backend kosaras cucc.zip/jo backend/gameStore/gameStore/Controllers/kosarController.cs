﻿using gameStore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace gameStore.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class kosarController : ControllerBase
    {

        /*[HttpGet("{uId}")]

        public async Task<IActionResult> Get(string uId, int id)
        {
            if (Program.LoggedInUsers.ContainsKey(uId))
            {
            using (var context = new jatekshopContext())
            {
                try
                {
                    return Ok(await context.Kosars.Include(f => f.Jatek).Include(f => f.Vasarlo).Where(f => f.VasarloId == id).ToListAsync());
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            }
            else
            {
                return BadRequest("Nincs jogosultsága");
            }
        }*/

        [HttpPost]
        public IActionResult jatekPostkosarelott(Osszesjatek jatek)
        {
            using (var context = new jatekshopContext())
            {
                try
                {
                    jatek.EgyediId = Program.GenerateID();
                    context.Add(jatek);
                    context.SaveChanges();
                    return Ok(jatek.EgyediId);
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message + "A játék nem került hozzáadásra.");
                }
            }
        }

        [HttpGet("{egyediId}")]

        public async Task<IActionResult> KosarAtrakas(int fId, int egyediId)
        {
           /* if (Program.LoggedInUsers.ContainsKey(fId))
            {*/
                using (var context = new jatekshopContext())
                {
                    try
                    {
                        var jatekKosar = context.Osszesjateks.Where(c => c.EgyediId == egyediId).ToList();
                        var felhasznaloKosar = context.Felhasznaloks.Where(f=>f.Id == fId).ToList();
                        if (jatekKosar[0].EgyediId == egyediId)
                        {
                            Kosar kosar = new Kosar();
                            kosar.Nev = jatekKosar[0].Nev;
                            kosar.Kategoria = jatekKosar[0].Kategoria;
                            kosar.Ar = jatekKosar[0].Ar;
                            kosar.Leiras = jatekKosar[0].Leiras;
                            kosar.Kep = jatekKosar[0].Kep;
                            kosar.VasarloId = 3;
                            kosar.JatekId = jatekKosar[0].Id;
                            kosar.Darab = 5;
                            context.Kosars.Add(kosar);
                            context.Osszesjateks.Remove(jatekKosar[0]);
                            context.SaveChanges();
                            return Ok("Kosárba helyezés sikeres!");
                        }
                        else
                        {
                            return BadRequest("Kosárba helyezés sikertelen!");
                        }
                    }
                    catch (Exception ex)
                    {
                        return BadRequest(ex.Message);
                    }
                }
           /*}
            else
            {
                return BadRequest("Nincs jogosultsága");
            }*/

        }
    }
}