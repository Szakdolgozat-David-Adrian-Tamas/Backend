﻿using gameStore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using System;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;

namespace gameStore.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class kosarController : ControllerBase
    {

        /*[HttpGet("{uId}")]

        public async Task<IActionResult> Get(string uId, int id)
        {
            if (Program.LoggedInUsers.ContainsKey(uId))
            {
            using (var context = new jatekshopContext())
            {
                try
                {
                    return Ok(await context.Kosars.Include(f => f.Jatek).Include(f => f.Vasarlo).Where(f => f.VasarloId == id).ToListAsync());
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            }
            else
            {
                return BadRequest("Nincs jogosultsága");
            }
        }*/

        [HttpPost]
        public IActionResult jatekPostkosarelott(Osszesjatek jatek)
        {
            using (var context = new jatekshopContext())
            {
                try
                {
                    context.Add(jatek);
                    context.SaveChanges();
                    return Ok("A játék sikeresen a kosárba került");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message + "A játék nem került bele a kosárba");
                }
            }
        }

        [HttpGet("{fId}")]

        public async Task<IActionResult> KosarAtrakas(string fId, int kosarid)
        {
           /* if (Program.LoggedInUsers.ContainsKey(fId))
            {*/
                using (var context = new jatekshopContext())
                {
                    try
                    {
                        var jatekKosar = context.Osszesjateks.Where(c => c.Id == kosarid).ToList();
                        if (jatekKosar.Count != 0)
                        {
                            Kosar kosar = new Kosar();
                            kosar.VasarloId = 3;
                            kosar.JatekId = jatekKosar[0].Id;
                            kosar.Darab = 3;
                            context.Kosars.Add(kosar);
                            context.Osszesjateks.Remove(jatekKosar[0]);
                            context.SaveChanges();
                            return Ok("ok");
                        }
                        else
                        {
                            return BadRequest("Kosárba helyezés sikertelen!");
                        }
                    }
                    catch (Exception ex)
                    {
                        return BadRequest(ex.Message);
                    }
                }
           /*}
            else
            {
                return BadRequest("Nincs jogosultsága");
            }*/

        }
    }
}