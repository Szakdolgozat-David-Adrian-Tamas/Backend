﻿using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

#nullable disable

namespace gameStore.Models
{
    public partial class Osszesjatek
    {
        public Osszesjatek()
        {
            Kosars = new HashSet<Kosar>();
        }

        public int Id { get; set; }
        public string Nev { get; set; }
        public string Kategoria { get; set; }
        public int Ar { get; set; }
        public string Leiras { get; set; }
        public byte[] Kep { get; set; }
        public DateTime Megjelenes { get; set; }

        [JsonIgnore]

        public virtual ICollection<Kosar> Kosars { get; set; }
    }
}
