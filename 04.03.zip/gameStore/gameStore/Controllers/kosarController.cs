﻿using gameStore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Win32;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace gameStore.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class kosarController : ControllerBase
    {

        [HttpGet("{uId}")]

        /*public async Task<IActionResult> Get(string uId, int id)
        {
            if (Program.LoggedInUsers.ContainsKey(uId))
            {
            using (var context = new jatekshopContext())
            {
                try
                {
                    return Ok(await context.Kosars.Include(f => f.Jatek).Include(f => f.Vasarlo).Where(f => f.VasarloId == id).ToListAsync());
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
            }
            else
            {
                return BadRequest("Nincs jogosultsága");
            }
        }*/

        [HttpPost]
        public IActionResult jatekPostkosarelott(Osszesjatek jatek)
        {
            using (var context = new jatekshopContext())
            {
                try
                {
                    context.Add(jatek);
                    context.SaveChanges();
                    return Ok("A játék sikeresen a kosárba került");
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message + "A játék nem került bele a kosárba");
                }
            }
        }

        [HttpGet("{fId}")]

        public IActionResult KosarAtrakas(int fId, int kosarid)
        {
            using (var context = new jatekshopContext())
            {
                try
                {
                    var jatekKosar = context.Osszesjateks.Where(c => c.Id == kosarid).ToList();
                    if (jatekKosar.Count != 0)
                    {
                        Kosar kosar = new Kosar();
                        kosar.JatekId = jatekKosar[0].Id;


                        context.Kosars.Add(kosar);
                        context.Osszesjateks.Remove(jatekKosar[0]);
                        context.SaveChanges();
                        return Ok("Kosárba helyezés sikeres.");
                    }
                    else
                    {
                        return BadRequest("Kosárba helyezés sikertelen!");
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message);
                }
            }
        }

        [HttpPut("{uId}")]
        public async Task<IActionResult> Put(string uId, Osszesjatek jatek)
        {
            using (var context = new jatekshopContext())
            {
                try
                {
                    context.Kosars.Update(jatek);
                    context.SaveChanges();
                    return StatusCode(290, "A kosár tartalmának módosítása sikeresen megtörtént.");
                }
                catch (Exception ex)
                {
                    return BadRequest("A kosár tartalmának módosítása sikertelen." + ex.Message);
                }
            }
        }

        [HttpDelete("{uId}")]
        public async Task<IActionResult> Delete(string uId, int Id)
        {
            using (var context = new jatekshopContext())
            {
                try
                {
                    Osszesjatek jatek = new Osszesjatek();
                    jatek.Id = Id;
                    context.Kosars.Remove(jatek);
                    context.SaveChanges();
                    return StatusCode(204, "A kosár tartalmának törlése sikeresen megtörtént.");
                }
                catch (Exception ex)
                {
                    return BadRequest("A kosár tartalmának törlése sikertelen." + ex.Message);
                }
            }
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteGameId(string uId, string gameId)
        {
            using (var context = new jatekshopContext())
            {
                try
                {
                    var jatek = context.Kosars.Where(f => f.JatekId == gameId).ToList();
                    if (jatek.Count > 0)
                    {
                        context.Kosars.Remove(jatek[0]);
                        context.SaveChanges();
                        return Ok("A kosár teljes tartalma törlésre került.");
                    }
                }
                catch (Exception ex)
                {
                    return BadRequest(ex.Message + "A kosár teljes tartalma nem törlődött!");
                }
            }
        }
    }
}