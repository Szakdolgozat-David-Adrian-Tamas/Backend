﻿using gameStore.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace gameStore.Controllers
{
    [Route("[controller]")]
    [ApiController]
    public class kosarController : ControllerBase
    {

        [HttpGet("{uId}")]

        public async Task <IActionResult> Get(string uId, int id)
        {
            /*if (Program.LoggedInUsers.ContainsKey(uId))
            {*/
                using (var context = new jatekshopContext())
                {
                    try
                    {
                        return Ok(await context.Kosars.Include(f => f.Jatek).Include(f => f.Vasarlo).Where(f => f.VasarloId == id).ToListAsync());
                    }
                    catch (Exception ex)
                    {
                        return BadRequest(ex.Message);
                    }
                }
            /*}
            else
            {
                return BadRequest("Nincs jogosultsága");
            }*/
        }
    }
}
